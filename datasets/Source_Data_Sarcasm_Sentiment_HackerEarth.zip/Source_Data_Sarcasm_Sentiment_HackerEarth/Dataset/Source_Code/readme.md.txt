Final codes of Icertis

1)Balanced Dataset in train dataset
2)Picked up two columns comments and parent comment
3)vectorized the using TfIdfVectorizer
4)used a logistic regression for the score
5)used f1 score for this process

6)used the test dataset for this purpose
7)saved the final outcome file